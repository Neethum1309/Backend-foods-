const Authors = require("../models/authorModel")

//let authors = []
//let authorIdCounter = 1
//Get all Authors
const getAllAuthors = async (req, res) => {
  const authors = await Authors.find({})
  res.json(authors)
  }
  //Get Authors by Id
const getAuthorsById =async (req, res) => {
  const author = await Authors.findById(req.params.authorId).exec()
  res.json(author)
  } 
  //Add Authors
const addAuthors = async(req, res) => {
//get author from the request body
   const authordata = req.body
//create document from the data
   const author = new Authors({authordata})
   await author.save()
   res.json(author)
   //console.log("Added authors successfully")
  }  
  //update authors 
const updateAuthors = async (req, res) => {
  const updateauthor = await Authors.findByIdAndUpdate(req.params.authorId, req.body, {new: true})
  res.json(updateAuthors)
  }  
  //Delete Authors
const deleteAuthors = async(req, res) => {
  await Authors.findByIdAndDelete(req.params.authorId)
  res.send("Author deleted successfully")
}  
  module.exports = {
    getAllAuthors,
    getAuthorsById,
    addAuthors,
    updateAuthors,
    deleteAuthors
  }