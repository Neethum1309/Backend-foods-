const Book = require("../models/bookModel")
//let books = [] 
//let idCounter = 1
const getAllBooks = async (req, res) => {
  const books = await Book.find({})
  res.json(books)
 }
const getBookById = async (req, res) => {
  const book = await Book.findById(req.params.bookId).exec()
  res.json(book)
  } 
const addBook = async(req, res) => {
  const bookdata = req.body
  const book = new Book(bookdata)
  await book.save()
  res.json(book)
  console.log("book added successfully")
  /*const book = {
    id: idCounter++,
    title: req.body.title,
    author: req.body.author,
    publishedDate: req.body.publishedDate,
    pages: req.body.pages,
    genre: req.body.genre,
};*/

  }  
const updateBook = async (req, res) => {
  const updatebook = await Book.findByIdAndUpdate(req.params.bookId, req.body, {new: true})
  res.json(updateBook)
  }  
const deleteBook = async (req, res) => {
  await Book.findByIdAndDelete(req.params.bookId)
  res.send("Book deleted successfully")
  
  }  
  module.exports = {
    getAllBooks,
    getBookById,
    addBook,
    updateBook,
    deleteBook
  }