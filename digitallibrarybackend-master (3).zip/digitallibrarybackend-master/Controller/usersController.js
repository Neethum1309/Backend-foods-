const User = require("../models/userModel")

//let users = []
//let userIdCounter = 1
const getAllUsers = async(req, res) => {
  await User.find({})
  res.json(users)
  }
const getUserById = async(req, res) => {
  const user = await Book.findById(req.params.userId).exec()
  res.json(user)
  }
const AddUser = async(req, res) => {
  const userdata = req.body
  const user = new User(userdata)
  await user.save()
  res.json(user)
  /*const user = {
    id: userIdCounter++,
    name: req.body.name,
    email: req.body.email,
    registrationDate: new Date(),
};*/

  }
const UpdateUser = async (req, res) => {
  const user =await User.findByIdAndUpdate(req.params.bookId, req.body, {new: true})
  res.json(user)
  }
const DeleteUser = async(req, res) => {
  await User.findByIdAndDelete(req.params.userId)
  res.send("User deleted successfully")
   }
  module.exports = {
    getAllUsers,
    getUserById,
    AddUser,
    UpdateUser,
    DeleteUser
  }        