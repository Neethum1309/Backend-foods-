const express = require('express')
const app = express()
var cors = require('cors') //for secure sites
const bookroutes = require('./routes/bookroutes')
const authorsroutes = require('./routes/authorroutes')
const userroutes = require('./routes/usersroutes')
const mongoose = require('mongoose');
const port = 3000
app.use(cors()) //for secure sites
app.use(express.json()) //to access the body parts of request
app.use('/book', bookroutes)
app.use('/authors', authorsroutes)  
app.use('/users', userroutes )
app.get('/', (req, res) => {
  res.send('Welcome to the home page');
});
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

main().then(()=>console.log("connected")).
catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb+srv://anchuashokan756:LdlOV8Fgna8WN0wL@cluster0.sjraxdt.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');
}