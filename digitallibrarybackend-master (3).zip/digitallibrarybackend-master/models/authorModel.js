const mongoose = require('mongoose')
const authorSchema = new mongoose.Schema({
      //id: Number,
      name: String,
      //bio: String,
      //birthdate: Date

  });
  const Authors = mongoose.model('Author', authorSchema)
  module.exports = Authors