const mongoose = require('mongoose')
const bookSchema = new mongoose.Schema({
    image: String,
    title: String,
    //author: String,
    publishedDate: Date,
    genre: String
  });
  const Book = mongoose.model('Book', bookSchema)
  module.exports = Book