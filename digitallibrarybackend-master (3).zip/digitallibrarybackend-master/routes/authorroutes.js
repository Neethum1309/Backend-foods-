const express = require('express')
const { getAllAuthors, getAuthorsById, addAuthors, updateAuthors, deleteAuthors } = require('../Controller/authorController')
const router = express.Router()
//Get all authors by Id
router.get('/', getAllAuthors)
  //Get authors by Id
  router.get('/:authorsId', getAuthorsById )
    //Add authors
    router.post('/', addAuthors)
    //Update authors by Id
    router.patch('/:authorsId', updateAuthors)
    //Delete authors by Id
    router.delete('/:authorsId', deleteAuthors)


module.exports = router