const express = require('express')
const { getAllBooks, getBookById, addBook, updateBook, deleteBook } = require('../Controller/bookController')
const router = express.Router()
  //Get all books
router.get('/', getAllBooks)
  //Get Books by Id
  router.get('/:bookId', getBookById)
    //Add books
    router.post('/', addBook)
    //Update books by Id
    router.patch('/:bookId',updateBook)
    //Delete books by Id
    router.delete('/:bookId',deleteBook)        
module.exports = router