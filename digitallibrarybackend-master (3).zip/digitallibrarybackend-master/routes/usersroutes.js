const express = require('express')
const { getAllUsers, getUserById, AddUser, UpdateUser, DeleteUser } = require('../Controller/usersController')
const app = express()
const router = express.Router();

// Get all users
router.get('/', getAllUsers)
//Get user by Id
router.get('/:userId', getUserById)
  //Add user
  router.post('/', AddUser)
  //Update user
  router.patch('/:userId', UpdateUser)
  //Delete user
  router.delete('/:userId', DeleteUser)
  module.exports = router